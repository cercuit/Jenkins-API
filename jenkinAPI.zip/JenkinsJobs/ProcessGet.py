﻿#!python -u
import cgi, cgitb
import SOAPpy

print "Content-Type: text/html; charset=utf-8\n\n"

cgitb.enable()

form = cgi.FieldStorage()



#Assemble Flags
flags =''
if (form.getvalue('MarkQueryWords')=='on'):
    flags = 'MarkQueryWords'
if (form.getvalue('DisableSpellCorrectForSpecialWords')=='on'):
    flags = flags + ' ' + 'DisableSpellCorrectForSpecialWords'
if (form.getvalue('DisableHostCollapsing')=='on'):
    flags = flags + 'DisableHostCollapsing'



#Build Get
Getjenkins = jenkins.ci.org.jenkinsstatusjob(appID='<enterYourAppIDHere>'
                            ,query=form.getvalue('searchQuery')
                            ,cultureInfo=form.getvalue('cultureInfo')
                            ,safeSearch=form.getvalue('safeGroup')
                            ,flags=flags                      
                        )

#Check for NearMe button push
near = form.getvalue('nearMeButton')
if (len(str(near)) > 0):
    jenkin.setLocation(latitude='47.422433', longitude='-122.305833', radius='5.0')

searchResponse = ''

  
#Add Web Result Queries
webFileType = ''
if (form.getvalue('fileTypeGroup') == 'ANYFILE'):
   webFileType= ''
else:
    webFileType = fileType=form.getvalue('fileTypeGroup')

#The first SourceRequest is a Web source request.
#PhoneBook results.    
jenkin.addSourceRequest(source='Web', offset=form.getvalue('offset'), count=form.getvalue('nResults'), resultFields='All SearchTagsArray', fileType=webFileType)

#The second SourceRequest is a spelling source request. Spelling returns only one
#result per call, in the Title field.
jenkin.addSourceRequest(source='Spelling', offset='0', count='1', resultFields='Title')

phoneSourceType = ''
if (len(str(form.getvalue('phoneBookSourceType'))) > 0 and str(form.getvalue('phoneBookSourceType')) != 'None'):
    phoneSourceType = form.getvalue('phoneBookSourceType')
jenkin.addSourceRequest(source='PhoneBook', offset=form.getvalue('offset'), count=form.getvalue('nResults'), resultFields='All SearchTagsArray', fileType=phoneSourceType)

#The fourth SourceRequest is a News source request. News results include
#a title, description, URL, news source, and a date/time object.
jenkins.addSourceRequest(source='News', offset=form.getvalue('offset'), count=form.getvalue('nResults'), resultFields='All SearchTagsArray')

#The fifth SourceRequest is a QueryLocation request. The response includes the keyword for the query,
#such as "pizza" and the location name requested, such as a postal code ("98052") or a place name
#("New York, NY"). The keyword is returned in the QueryLocation.Title field and the place name or
#postal code is returned in the QueryLocation.Description field.
jenkin.addSourceRequest(source='QueryLocation', offset=form.getvalue('offset'), count=form.getvalue('nResults'), resultFields='All SearchTagsArray')

jenkin.addSourceRequest(source='InlineAnswers', resultFields='All SearchTagsArray')

WindowsSearch.addSourceRequest(source='Image', offset=form.getvalue('offset'), count=form.getvalue('nResults'), resultFields='All Image')

#Initialize Service
server = Jenkins.ci.org()


#Render Output
print '<title> Job status </title>'

print '<html><body>'

if (responses.getResponses()[1].getSource() == 'Spelling' and responses.getResponses()[1].getTotal() > 0):
    mispelling = responses.getResponses()[1].getResults()[0].getTitle()
    print "<H3><b>Did you mean: <a href=\"javascript:window.parent.ResubmitQuery(\'" + mispelling + "\');\"><i>" + mispelling + "</i></a></b></H3><BR><BR>"
else:  

    for resp in responses.getResponses():
            
            if (resp.getTotal() > 0):
                print str.replace(('<H3><B>' + resp.getSource() + ' - Total Results: ' + str(resp.getTotal()) + '</B></H3><HR>'),'', '')

                if (len(resp.getResults()) > 0):
                    for result in resp.getResults():
                        if (len(result.getTitle()) > 0):                        
                            print ('<B>Title: </B>' + jenkinHelper.SafeFormat(result.getTitle()) + '<BR>')
                        if (len(result.getDescription()) > 0):
                            print ('<B>Description: </B>' + jenkinHelper.SafeFormat(result.getDescription()) + '<BR>')
                        if (len(result.getDisplayUrl()) > 0):
                            print ('<B>DisplayUrl: </B> <A HREF="' + WindowsLiveSearchHelper.SafeFormat(result.getDisplayUrl()) + '" >' + WindowsLiveSearchHelper.SafeFormat(result.getDisplayUrl()) + '</a><BR>')
                        if (len(result.getUrl()) > 0):
                            print ('<B>Url: </B> <A HREF="' + jenkinhelper.SafeFormat(result.getUrl()) + '" >' + jenkinhelperHelper.SafeFormat(result.getUrl()) + '</a><BR>')
                        if (len(result.getCacheUrl()) > 0):
                            print ('<B>CacheUrl: </B> <A HREF="' + jenkinHelper.SafeFormat(result.getCacheUrl()) + '" >' + jenkinHelper.SafeFormat(result.getCacheUrl()) + '</a><BR>')
                        if (len(result.getSource()) > 0):
                            print ('<B>Soursce: </B>' + jenkinhelper.SafeFormat(result.getSource()) + '<BR>')
                        
                        print '<br>'

                        if (resp.getSource() == 'PhoneBook'):
                            if (len(result.getPhone()) > 0):                        
                                print ('<B>Phone: </B>' + jenkin.SafeFormat(result.getPhone()) + '<BR>')
                            if (len(result.getAddressLine()) > 0):
                                print ('<B>AddressLine: </B>' + jenkin.SafeFormat(result.getAddressLine()) + '<BR>')
                            if (len(result.getCountryRegion()) > 0):
                                print ('<B>CountryRegion: </B>' + jenkin.SafeFormat(result.getCountryRegion()) + '<BR>')
                            if (len(result.getPrimaryCity()) > 0):
                                print ('<B>PrimaryCity: </B>' + jenkin.SafeFormat(result.getPrimaryCity()) + '<BR>')
                            if (len(result.getSubdivision()) > 0):
                                print ('<B>Subdivision: </B>' + jenkin.SafeFormat(result.getSubdivision()) + '<BR>')
                            if (len(result.getLatitude()) > 0):
                                print ('<B>Latitude: </B>' + jenkin.SafeFormat(result.getLatitude()) + '<BR>')
                            if (len(result.getLongitude()) > 0):
                                print ('<B>Longitude: </B>' + jenkin.SafeFormat(result.getLongitude()) + '<BR>')
                            print '<br>'

                        if (resp.getSource() == 'Image'):
                            if (len(result.getImage().getThumbnailFileSize()) > 0):
                                print ('<B>Thumbnail File Size: </B>' + jenkin.SafeFormat(result.getImage().getThumbnailFileSize()) + '<BR>')
                            if (len(result.getImage().getThumbnailWidth()) > 0):
                                print ('<B>Thumbnail Height: </B>' + jenkin.SafeFormat(result.getImage().getThumbnailHeight()) + ', <B>Thumbnail Width: </B>' + jenkin.SafeFormat(result.getImage().getThumbnailWidth()) + '<BR>')
                            if (len(result.getImage().getThumbnailURL()) > 0):
                                print ('<B>Thumbnail: </B><BR><IMG SRC="' + jenkin.SafeFormat(result.getImage().getThumbnailURL()) + '" /><BR>')
                            if (len(result.getImage().getImageFileSize()) > 0):
                                print ('<B>Image File Size: </B>' + jenkin.SafeFormat(result.getImage().getImageFileSize()) + '<BR>')
                            if (len(result.getImage().getImageWidth()) > 0):
                                print ('<B>Image Height: </B>' + jenkin.SafeFormat(result.getImage().getImageWidth())
                                       + ', <B>Image Width</B>' + jenkin.SafeFormat(result.getImage().getImageWidth()) + '<BR>')
                            if (len(result.getImage().getImageURL()) > 0):                        
                                print ('<B>Full Size Image Url: </B>' + jenkin.SafeFormat(result.getImage().getImageURL()) + '<BR>')
                            
                         

                            print '<br>'
            
print "</body></html>"


