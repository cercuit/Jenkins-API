﻿import SOAPpy


class Request:

    #MemberFields
    _appID = ''
    _query = ''
    _cultureInfo =  SOAPpy.Types.untypedType('')
    _safeSearch =  SOAPpy.Types.untypedType('')
    _flags = SOAPpy.Types.untypedType('')
    _sourceRequests = []
    _location = SOAPpy.structType()

    
    def __init__(self, appID, query, cultureInfo, safeSearch, flags):
        self._appID = appID
        self._query = query
        self._cultureInfo = SOAPpy.Types.untypedType(cultureInfo)
        self._safeSearch = SOAPpy.Types.untypedType(safeSearch)
        self._flags = SOAPpy.Types.untypedType(flags)
        
       

    def getRequest(self):
        searchRequest = SOAPpy.structType()
        searchRequest._addItem('AppID', self._appID)
        searchRequest._addItem('Query', self._query)
        searchRequest._addItem('CultureInfo', self._cultureInfo)
        searchRequest._addItem('SafeSearch', self._safeSearch)
        searchRequest._addItem('Flags', self._flags)
        searchRequest._addItem('Requests', SOAPpy.Types.arrayType(self._sourceRequests))
        searchRequest.Requests._elemsname = "SourceRequest"
        searchRequest._addItem('Location', self._location)

        return searchRequest

    def addSourceRequest(self, source='', offset='', count='', resultFields='', fileType=''):
        self._sourceRequests.append(SOAPpy.structType(data={ 'Source': SOAPpy.Types.untypedType(source)
                                    ,'Offset': SOAPpy.Types.untypedType(offset)
                                    ,'Count': SOAPpy.Types.untypedType(count)
                                    ,'ResultFields': SOAPpy.Types.untypedType(resultFields)
                                    ,'FileType': SOAPpy.Types.untypedType(fileType)
                                    }
                                    )
                                   )

    def setLocation(self, latitude, longitude, radius):
        self._location = SOAPpy.structType()
        self._location._addItem('Latitude', latitude)
        self._location._addItem('Longitude', longitude)
        self._location._addItem('Radius', radius)


class WebImage:
    _imageURL =''
    _imageWidth = 0
    _imageHeight = 0
    _imageFileSize = 0
    _thumbnailURL = ''
    _thumbnailWidth = 0
    _thumbnailHeight = 0
    _thumbnailFileSize = 0


    def __init__(self, ImageURL='', ImageWidth='', ImageHeight='', ImageFileSize='', ThumbnailURL='', ThumbnailHeight='',
                 ThumbnailWidth='', ThumbnailFileSize=''):
        self._imageURL = ImageURL
        self._imageWidth = ImageWidth
        self._imageHeight = ImageHeight
        self._imageFileSize = ImageFileSize
        self._thumbnailURL = ThumbnailURL
        self._thumbnailWidth = ThumbnailWidth
        self._thumbnailHeight = ThumbnailHeight
        self._thumbnailFileSize = ThumbnailFileSize

    def getImageURL(self):
        return self._imageURL
    def getImageWidth(self):
        return self._imageWidth
    def getImageHeight(self):
        return self._imageHeight
    def getImageFileSize(self):
        return self._imageFileSize
    def getThumbnailURL(self):
        return self._thumbnailURL
    def getThumbnailWidth(self):
        return self._thumbnailWidth
    def getThumbnailHeight(self):
        return self._thumbnailHeight
    def getThumbnailFileSize(self):
        return self._thumbnailFileSize 

class Result:
    _title = ''
    _url = ''
    _source = ''
    _displayUrl = ''
    _cacheUrl = ''
    _description = ''
    _phone = ''
    _addressLine = ''
    _primaryCity = ''
    _subdivision = ''
    _postalCode = ''
    _countryRegion = ''
    _latitude = ''
    _longitude = ''
    _image = WebImage()
   
    


    def __init__(self, Title='', Url='', Source='', DisplayUrl='', Description='', CacheUrl='',
                 Phone='', AddressLine = '', PrimaryCity='', Subdivision='', PostalCode='', CountryRegion='',
                 Latitude='', Longitude='', Image=WebImage()):
        self._title = Title
        self._url = Url
        self._source = Source
        self._displayUrl = DisplayUrl
        self._description = Description
        self._cacheUrl = CacheUrl
        self._phone = Phone
        self._addressLine = AddressLine
        self._primaryCity = PrimaryCity
        self._subdivision = Subdivision
        self._postalCode = PostalCode
        self._countryRegion = CountryRegion
        self._latitude = Latitude
        self._longitude = Longitude
        self._image = Image

    def getTitle(self):
        return self._title
    def getUrl(self):
        return self._url
    def getSource(self):
        return self._source
    def getDisplayUrl(self):
        return self._displayUrl
    def getCacheUrl(self):
        return self._cacheUrl
    def getDescription(self):
        return self._description
    def getPhone(self):
        return self._phone
    def getAddressLine(self):
        return self._addressLine
    def getPrimaryCity(self):
        return self._primaryCity
    def getSubdivision(self):
        return self._subdivision
    def getPostalCode(self):
        return self._postalCode
    def getCountryRegion(self):
        return self._countryRegion
    def getLatitude(self):
        return self._latitude
    def getLongitude(self):
        return self._longitude
    def getImage(self):
        return self._image

    

class SourceResponse:
    
    _source = ''
    _total = 0
    _offset = 0
    _results = []
    
    
    def __init__(self, WindowsLiveSourceResponse):
        #get newlist
        self._results = []

        #make sure its a valid dict 
        if isinstance(WindowsLiveSourceResponse, dict):
            #Load Fields
                            title = ''
                            url = ''
                            source = ''
                            displayUrl = ''
                            cacheUrl = ''
                            description = ''
                            phone = ''
                            addressLine = ''
                            primaryCity = ''
                            subdivision = ''
                            postalCode = ''
                            countryRegion = ''
                            latitude = ''
                            longitude = ''
                            image = WebImage()
                            imageURL =''
                            imageWidth = 0
                            imageHeight = 0
                            imageFileSize = 0
                            thumbnailURL = ''
                            thumbnailWidth = 0
                            thumbnailHeight = 0
                            thumbnailFileSize = 0
                            
                            if(srcResponse.has_key('Title')):
                                title = srcResponse['Title']                               
                            if(srcResponse.has_key('Url')):
                                url = srcResponse['Url']
                            if(srcResponse.has_key('Source')):
                                source = srcResponse['Source']
                            if(srcResponse.has_key('DisplayUrl')):
                                displayUrl = srcResponse['DisplayUrl']
                            if(srcResponse.has_key('CacheUrl')):
                                cacheUrl = srcResponse['CacheUrl'] 
                            if(srcResponse.has_key('Description')):
                                description = srcResponse['Description']
                            if(srcResponse.has_key('Phone')):
                                phone = srcResponse['Phone']
                            #Get Address Info
                            if(srcResponse.has_key('Address')):
                                if(srcResponse['Address'].has_key('AddressLine')):
                                    addressLine = srcResponse['Address']['AddressLine']
                                if(srcResponse['Address'].has_key('PrimaryCity')):
                                    primaryCity = srcResponse['Address']['PrimaryCity']
                                if(srcResponse['Address'].has_key('Subdivision')):
                                    subdivision = srcResponse['Address']['Subdivision']
                                if(srcResponse['Address'].has_key('PostalCode')):
                                    postalCode = srcResponse['Address']['PostalCode']
                                if(srcResponse['Address'].has_key('CountryRegion')):
                                    countryRegion = srcResponse['Address']['CountryRegion']
                            #Get Location Info
                            if(srcResponse.has_key('Location')):
                                if(srcResponse['Location'].has_key('Latitude')):
                                    latitude = srcResponse['Location']['Latitude']
                                if(srcResponse['Location'].has_key('Longitude')):
                                    longitude = srcResponse['Location']['Longitude']
                            #Get Image Info
                            if(srcResponse.has_key('Image')):
                                if(srcResponse['Image'].has_key('ImageURL')):
                                    imageURL = srcResponse['Image']['ImageURL']
                                if(srcResponse['Image'].has_key('ImageWidth')):
                                    imageWidth = srcResponse['Image']['ImageWidth']
                                if(srcResponse['Image'].has_key('ImageHeight')):
                                    imageHeight = srcResponse['Image']['ImageHeight']
                                if(srcResponse['Image'].has_key('ImageFileSize')):
                                    imageFileSize = srcResponse['Image']['ImageFileSize']
                                if(srcResponse['Image'].has_key('ThumbnailURL')):
                                    thumbnailURL = srcResponse['Image']['ThumbnailURL']
                                if(srcResponse['Image'].has_key('ThumbnailWidth')):
                                    thumbnailWidth = srcResponse['Image']['ThumbnailWidth']
                                if(srcResponse['Image'].has_key('ThumbnailHeight')):
                                    thumbnailHeight = srcResponse['Image']['ThumbnailHeight']
                                if(srcResponse['Image'].has_key('ThumbnailFileSize')):
                                    thumbnailFileSize = srcResponse['Image']['ThumbnailFileSize']
                                    
                                image = WebImage(ImageURL=imageURL, ImageWidth=imageWidth, ImageHeight=imageHeight, ImageFileSize=imageFileSize,
                                                 ThumbnailURL=thumbnailURL, ThumbnailHeight=thumbnailHeight,
                                                 ThumbnailWidth=thumbnailWidth, ThumbnailFileSize=thumbnailFileSize)
                                
                            result =  Result(Title=title, Url=url, Source=source, DisplayUrl=displayUrl, CacheUrl=cacheUrl, Description=description,
                                             Phone=phone, AddressLine=addressLine, PrimaryCity=primaryCity, Subdivision=subdivision, PostalCode=postalCode, CountryRegion=countryRegion,
                                             Latitude=latitude, Longitude=longitude, Image=image)
                            self._results.append(result)


            
    def getSource(self):
        return self._source

    def getTotal(self):
        return self._total

    def getOffset(self):
        return self._offset

    def getResults(self):
        return self._results

#Holds the top Level Response
class WindowsLiveSearchResponse:

    _sourceResponses = []

    def __init__(self, Response):
        if isinstance(Response, dict):
            if (Response.has_key('Responses')):
                responses = SOAPpy.structType(Response['Responses'])
                if (Response['Responses'].has_key('SourceResponse')):
                    for result in responses.SourceResponse:
                        self._sourceResponses.append(SourceResponse(result))
        
    def getResponses(self):
        return self._sourceResponses


class WindowsLiveSearchService:

    _url = ''
    _ns = ''
    
    
    def __init__(self):
        self._url = 'http://soap.search.msn.com/webservices.asmx?wsdl'
        self._ns = 'http://schemas.microsoft.com/MSNSearch/2005/09/fex'

        
    def Search(self, WindowsLiveSearchRequest):
        SOAPpy.Config.simplify_objects = 1
        server = SOAPpy.SOAPProxy(self._url, self._ns)
        return WindowsLiveSearchResponse(server.Search(Request=WindowsLiveSearchRequest.getRequest()))


#formats string to print html
def SafeFormat(badstring):
    return str.replace(str.replace((badstring.encode('utf-8')),'', '<b>'), '', '</b>')
